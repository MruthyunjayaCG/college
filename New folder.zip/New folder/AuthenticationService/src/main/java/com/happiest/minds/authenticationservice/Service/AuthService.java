package com.happiest.minds.authenticationservice.Service;

import com.happiest.minds.authenticationservice.Repository.AuthRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;


import java.util.List;

@Service
public class AuthService {

    @Autowired
    private AuthRepo authRepo;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Autowired
    RestTemplate restTemplate;


//    public List<User> getUsers(){
//        return authRepo.findAll();
//    }

//    public User createUser(User user){
//
//        user.setUserId(UUID.randomUUID().toString());
//        user.setPassword(passwordEncoder.encode(user.getPassword()));
//        return authRepo.save(user);
//    }

}
