package com.happiest.minds.authenticationservice.Repository;


import org.apache.catalina.User;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface AuthRepo extends JpaRepository<User,String>
{
    Optional<User> findByUsername(String username);
}

