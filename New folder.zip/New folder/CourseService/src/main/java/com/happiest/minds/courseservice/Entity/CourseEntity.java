package com.happiest.minds.courseservice.Entity;

import jakarta.persistence.*;
import lombok.Data;

@Entity
@Table(name = "Course")
@Data
public class CourseEntity
{
        @Id
        @GeneratedValue(strategy = GenerationType.AUTO)
        private Integer Id;
        private String courseId;
        private String courseName;
        private String duration;
        private Integer teacherId;

        public Integer getId() {
                return Id;
        }

        public void setId(Integer id) {
                Id = id;
        }

        public String getCourseId() {
                return courseId;
        }

        public void setCourseId(String courseId) {
                this.courseId = courseId;
        }

        public String getCourseName() {
                return courseName;
        }

        public void setCourseName(String courseName) {
                this.courseName = courseName;
        }

        public String getDuration() {
                return duration;
        }

        public void setDuration(String duration) {
                this.duration = duration;
        }

        public Integer getTeacherId() {
                return teacherId;
        }

        public void setTeacherId(Integer teacherId) {
                this.teacherId = teacherId;
        }
}
