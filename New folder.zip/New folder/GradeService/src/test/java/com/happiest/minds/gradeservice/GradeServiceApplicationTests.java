package com.happiest.minds.gradeservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GradeServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
