package com.happiest.minds.gradeservice.Response;

import lombok.Data;

@Data
public class CourseEntity
{
    private Integer Id;
    private String courseName;
    private Integer courseId;
    private String duration;
}
