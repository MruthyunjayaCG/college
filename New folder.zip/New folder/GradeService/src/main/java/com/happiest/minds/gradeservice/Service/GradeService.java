package com.happiest.minds.gradeservice.Service;

import com.happiest.minds.gradeservice.Entity.GradeEntity;
import com.happiest.minds.gradeservice.Repository.Graderepository;
import com.happiest.minds.gradeservice.Response.CourseEntity;
import com.happiest.minds.gradeservice.Response.Student;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.client.RestTemplate;

import java.util.*;
import java.util.stream.Collectors;

import static java.util.stream.Collectors.groupingBy;

@Service
public class GradeService {

    @Autowired
    Graderepository gradeRepository;

    @Autowired
    RestTemplate restTemplate;

    public GradeEntity create(@RequestBody GradeEntity gradeEntity) {
        return gradeRepository.save(gradeEntity);
    }

    public Optional<GradeEntity> getGrade(Integer id) {
        return gradeRepository.findById(id);
    }

    public List<GradeEntity> getGradeByCourse(String courseId) {
        return gradeRepository.findAllByCourseId(courseId);
    }

    public String getStudentName(Integer studentId)
    {
        Student student = restTemplate.getForObject("http://localhost:8082/student/" + studentId,Student.class);
        return student.getFirstName().concat("").concat(student.getLastName());
    }

    public String getCourseName(Integer courseId)
    {
        Student student = restTemplate.getForObject("http://localhost:8084/Course/" + courseId, Student.class);
        return student.getFirstName().concat("").concat(student.getLastName());
    }

    public Map<String, List<String>> getStudentByCourseId(String courseId) {
        Map<String, List<String>> gradeCourseMap = new HashMap<>();
        List<GradeEntity> gradeEntities = gradeRepository.findAllByCourseId(courseId);
//        Map<String, List<String>> getStudentByCourseId=
//        this.getGrade()
//                .stream()
//                .collect(Collectors.groupingBy(e->e.getCourseId()));
        System.out.println("gradeEntities = " + gradeEntities);
        Map<String, List<GradeEntity>> collect = gradeEntities.stream().collect(groupingBy(GradeEntity::getGrade));
//        for (List<GradeEntity> entities : collect) {
//            String fullname = getStudentName(collect.get());
//        }
        System.out.println("collect = " + collect);
        Map<String, List<String>> finalMap = new HashMap<>();
        for (Map.Entry<String,List<GradeEntity>> entry : collect.entrySet()) {
            List<String> studentNames = new ArrayList<>();
            for (int i = 0; i < entry.getValue().size(); i++) {
                GradeEntity gradeEntity = entry.getValue().get(i);
                String fullname = getStudentName(gradeEntity.getUserId());
                studentNames.add(fullname);
                finalMap.put(entry.getKey(), studentNames);
            }
        }
        return finalMap;
//        System.out.println("finalMap = " + finalMap);
//        List<String> studentlist = new ArrayList<>();
//
//        Map<String,List<GradeEntity>> GradeById = studentlist.stream().collect(Collectors.groupingBy(GradeEntity::getGrade));
//        System.out.println("Grades="+GradeById);


//        Map<String, List<GradeEntity>> getStudentByCourseId = studentlist.stream().collect(groupingBy(GradeEntity::getGrade));
//
//
//        String Grade = gradeRepository.findGradeByCourseId(courseId).getGrade();
//        for (GradeEntity gradeEntity : gradeEntities)
//        {
//            String fullname = getStudentName(gradeEntity.getUserId());
////            Map<String, List<Map<String,List<String>>>> gradeStudentMap = new HashMap<>();
////            List<GradeEntity> gradeEntities1 = gradeRepository.findAllByCourseId(courseId);
//            studentlist.add(fullname);
//        }
//        gradeCourseMap.put(Grade,studentlist);
//        return gradeCourseMap;
//        return null;
    }

    public GradeEntity update(GradeEntity gradeEntity) {
        return gradeRepository.save(gradeEntity);
    }

    public void delete(Integer id) {
        gradeRepository.deleteById(id);
    }

//    public List<GradeEntity> getAllGrade() {
//        return gradeRepository.findAll();
//    }
}
