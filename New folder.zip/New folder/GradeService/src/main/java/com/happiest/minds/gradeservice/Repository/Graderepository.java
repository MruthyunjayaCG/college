package com.happiest.minds.gradeservice.Repository;

import com.happiest.minds.gradeservice.Entity.GradeEntity;
import com.happiest.minds.gradeservice.Service.GradeService;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface Graderepository extends JpaRepository<GradeEntity,Integer> {
    List<GradeEntity> findAllByCourseId(String courseId);

    GradeEntity findGradeByCourseId(String courseId);
}
