package com.happiest.minds.teacherservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TeacherServiceApplicationTests {

    @Test
    void contextLoads() {
    }

}
