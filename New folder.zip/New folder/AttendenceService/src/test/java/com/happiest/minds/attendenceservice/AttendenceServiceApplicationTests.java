package com.happiest.minds.attendenceservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AttendenceServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
