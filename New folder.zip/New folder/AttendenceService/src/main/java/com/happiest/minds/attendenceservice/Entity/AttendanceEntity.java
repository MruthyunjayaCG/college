package com.happiest.minds.attendenceservice.Entity;

import jakarta.persistence.*;
import lombok.Data;

import java.time.LocalDate;
import java.util.Date;

@Entity
@Table(name = "attendance")
@Data
public class AttendanceEntity
{
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(name = "student_id")
    private Integer studentId;

    @Column(name = "course_id")
    private String courseId;

    @Column(name = "date")
    private LocalDate date = LocalDate.now();
}