package com.happiest.minds.attendenceservice.Repository;

import com.happiest.minds.attendenceservice.Entity.AttendanceEntity;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface AttendanceRepository extends JpaRepository<AttendanceEntity,Integer>
{
    List<AttendanceEntity> findAllByCourseId(String courseId);
}