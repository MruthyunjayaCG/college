package com.happiest.minds.attendenceservice.Response;

import lombok.Data;

@Data
public class Student
{
    private Long id;
    private Integer userId;
    private String firstName;
    private String lastName;
}
