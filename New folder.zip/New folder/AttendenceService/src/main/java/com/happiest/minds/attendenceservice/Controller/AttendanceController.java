package com.happiest.minds.attendenceservice.Controller;

import com.happiest.minds.attendenceservice.Entity.AttendanceEntity;
import com.happiest.minds.attendenceservice.Service.AttendanceService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;

import java.util.List;
import java.util.Optional;


@RestController
@RequestMapping("/Attendance")
@Slf4j
public class AttendanceController
{
//    private static final Logger log = LoggerFactory.getLogger(AttendanceController.class);
    @Autowired
    AttendanceService attendanceService;

    @Autowired
    RestTemplate restTemplate;

    @PostMapping
    public AttendanceEntity create(@RequestBody AttendanceEntity attendanceEntity)
    {
//        log.info("attendaceEntity:{}",attendanceEntity);
        return attendanceService.create(attendanceEntity);
    }

    @GetMapping("/{id}")
    public Optional<AttendanceEntity> getAttendance(@PathVariable(name = "id") Integer id)
    {
        return attendanceService.getAttendance(id);
    }

    @GetMapping("course/{courseId}")
    public List<AttendanceEntity> getAttendanceByCourse(@PathVariable String courseId) {
//        log.info("courseId: {}", courseId);
        return attendanceService.getAttendanceByCourse(courseId);
    }

}