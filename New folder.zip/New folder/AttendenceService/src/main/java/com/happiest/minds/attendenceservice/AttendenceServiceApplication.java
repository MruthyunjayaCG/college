package com.happiest.minds.attendenceservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AttendenceServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(AttendenceServiceApplication.class, args);
	}

}