package com.happiest.minds.attendenceservice.Response;

import lombok.Data;

@Data
public class StudentCourse
{
    private Integer id;
    private Integer studentId;
    private Integer courseId;
}
