package com.happiest.minds.userservice.Response;

import lombok.Data;

@Data
public class Student
{
    private Integer id;
    private Integer userId;
    private String firstName;
    private String lastName;
}
